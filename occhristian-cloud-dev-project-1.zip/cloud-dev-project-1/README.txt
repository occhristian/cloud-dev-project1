Cloudfront domain name:
https://d3dea2mnnsk7pp.cloudfront.net

Website-endpoint:
http://occhristian-udacity-starter-website.s3-website.us-east-1.amazonaws.com/

S3 object URL:
https://occhristian-udacity-starter-website.s3.amazonaws.com/index.html


##
ONLY MADE A FEW CHANGES TO ORIGINAL ZIP FILE:
Few CSS tweaks to the header and the article that use media queries on very small screens, and then changed the text in the banner a bit.

Thanks for the challenge! I learnt something new! I am still learning!
